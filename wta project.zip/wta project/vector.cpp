#include <iostream>
#include <vector>


using namespace std;
using std::vector;
void heapify(int a[],int m,int i)
{
    int swap;
    if(2*i+2<m)
    {
        heapify(a,m,2*i+1);
        heapify(a,m,2*i+2);
        if(a[2*i+2]<a[2*i+1])
        {
            if(a[2*i+2]<a[i])
         {
            swap=a[2*i+2];
            a[2*i+2]=a[i];
            a[i]=swap;
         }
        }
        else if(a[2*i+1]<a[i])
        {
           swap=a[2*i+1];
            a[2*i+1]=a[i];
            a[i]=swap; 
        }
    }
    else if(2*i+1<m)
    {
       swap=a[2*i+1];
            a[2*i+1]=a[i];
            a[i]=swap;  
    }
}

void heapinsert(int i,int a[],int m,int l)
{
    
    if(l<m)
    {
        
        a[l]=i;
        l=l+1;
        heapify(a,l,0);
    }
    else if(a[0]<i)
    {
        for (int j= 0; j <m; j++)
        {
            cout<<"after m elemenets :: "<<a[j]<< "  ";
            /* code */
        }
    a[0]=i;
        heapify(a,m,0);
        
        
        
    }
    
}
int main()
{
    vector<int> mallu={0};
    int n,s,m,f,count=0;
    int a[m];
    cin>>n;
    for(int i=0;i<n;i++)
    {
        cin>>s>>m;
        cout<<"s= "<<s<<"  m="<<m<<" \n";
        count=count+m;
        int j=0;
        for(j;j<s;j++)
        {
           cin>>f;
           heapinsert(f,a,m,j);
        }
        cout<<"\n";
        for(int c=0;c<m;c++)
        {
            cout<<a[c]<<" ";
           mallu.push_back(a[c]) ;
        }
    
    }
    cout<<"\n";
    for( int i=0;i<count+1;i++)
    {
        cout<<mallu.at(i)<<" ";
    }

    return 0;
}