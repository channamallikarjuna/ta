#include<iostream>
using namespace std;

void partition(int l,int h)
{
  int i=l,j=h,swap;
  while(i<j)
  {
  do
  {
    i++;
  }while(a[i]<a[l]);
  do
  {
    j--;
  }while(a[j]>a[l]);
  if(i<j)
  {
    swap=a[i];
    a[i]=a[j];
    a[j]=swap;
  }
}
swap=a[l];
a[l]=a[j];
a[j]=swap;
}

void quicksort(int l,int h)
{
  int j=partition(l,h);
  quicksort(l,j);
  quicksort(j+1,h);
}

int main()
{
  int n;
  cin>>n;
  int a[n+1];
  for(int i=0;i<n;i++)
  {
    cin>>a[i];
  }
a[n]=INT_MAX;
  quicksort(0,n);
  return 0;

}